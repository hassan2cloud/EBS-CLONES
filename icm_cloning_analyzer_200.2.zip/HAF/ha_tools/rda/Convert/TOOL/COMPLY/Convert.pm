# Convert.pm: Conversions for TOOL.comply Reports

package Convert::TOOL::COMPLY::Convert;

# $Id: Convert.pm,v 1.6 2014/08/25 13:03:26 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/Convert/TOOL/COMPLY/Convert.pm,v 1.6 2014/08/25 13:03:26 RDA Exp $
#
# Change History
# 20140825  MSC  Add tag conversions.

=head1 NAME

Convert::TOOL::COMPLY::Convert - Conversions for TOOL.comply Reports

=head1 SYNOPSIS

 require Convert::TOOL::COMPLY::Convert;

=head1 DESCRIPTION

This package regroups conversion methods for the TOOL.comply reports.

=cut

use strict;

BEGIN
{ use Exporter;
  use RDA::Text qw(get_string);
  use RDA::Driver::Convert;
}

# Define the global public variables
use vars qw($STRINGS $VERSION @ISA %PLUGIN);
$VERSION = sprintf('%d.%02d', q$Revision: 1.6 $ =~ /(\d+)\.(\d+)/);
@ISA     = qw(Exporter);
%PLUGIN  = (
  cnv => [{blk => {
             meta => [
               [qr{^Rule },
                {q{<} => \&begin_rule,
                 q{-} => \&add_rule_info,
                 q{>} => \&end_rule,
                }]
               ],
             res => [
               [qr{^Rule },
                {q{<} => \&begin_rule,
                 q{-} => \&add_rule_info,
                 q{>} => \&end_rule,
                }],
               [qr{^Test Results$},  ## no critic (Fix)
                {q{*} => 'Results',
                 q{=} => 1,
                }]
               ],
             },
           nam => 'Table Improvements',
           rnk => 10,
           sel => \&RDA::Driver::Convert::sel_block,
           typ => 'T',
          },
          {blk => {
             meta => [
               [qr{^\w+ Target Type$},
                {q{*} => q{Target},
                 q{-} => \&format_type_section,
                }]
               ],
             res => [
               [qr{^.+ Target$},
                {q{*} => q{Target},
                 q{-} => \&format_target_section,
                }],
               [qr{^Failure Summary$},  ## no critic (Fix)
                {q{*} => q{Failures},
                 q{-} => \&format_failure_section,
                }],
               [qr{^Test Results$},      ## no critic (Fix)
                {q{*} => q{},
                 q{-} => \&format_result_section,
                }]
               ],
             },
           nam => 'Section Improvements',
           rnk => 10,
           sel => \&RDA::Driver::Convert::sel_block,
           typ => 'S',
          },
         ],
  );

# Define the global private constants

# Define the global private variables
my %tb_rul = (
  Identifier => q{id},
  Name       => q{name},
  Severity   => q{severity},
  Status     => q{status},
  Version    => q{version},
  );
my %tb_tag = (
  description    => q{Description},
  failed         => q{FailMessage},
  passed         => q{PassMessage},
  recommendation => q{Recommendation},
  );

# Report the package version
sub Version
{ return $VERSION;
}

# Format a rule row
sub begin_rule
{ my ($ctl) = @_;

  $ctl->{'_tbl'} = {att => {}};
  return;
}

sub add_rule_info
{ my ($ctl, $lin) = @_;
  my ($hdr, $txt);

  ($hdr, $txt) = $ctl->get_cells($lin);
  if ($hdr =~ s/^\*(.*)\*$/$1/)
  { if (exists($tb_rul{$hdr}))
    { $ctl->{'_tbl'}->{'att'}->{$tb_rul{$hdr}} = $ctl->rpl_var($txt);
    }
    else
    { $ctl->{'_tbl'}->{'det'}->{$ctl->cnv_attr($hdr)} = ($txt =~ m/^\w+$/)
        ? $txt
        : q{<![CDATA[}.$ctl->rpl_var($txt).q{]]>};
    }
  }
  return;
}

sub end_rule
{ my ($ctl) = @_;
  my ($buf, $tag, $tbl, $txt);

  $buf = q{<Rule};
  foreach my $key (sort keys(%{$tbl = $ctl->{'_tbl'}->{'att'}}))
  { $buf .= qq{ $key='}.$tbl->{$key}.q{'};
  }
  if (exists($ctl->{'_tbl'}->{'det'}))
  { $buf .= qq{>\n};
    foreach my $key (sort keys(%{$tbl = $ctl->{'_tbl'}->{'det'}}))
    { $txt = $tbl->{$key};
      $txt =~ s{<sdp_a }{<a }g;
      $txt =~ s{</sdp_a>}{</a>}g;
      if (exists($tb_tag{$key}))
      { $tag = $tb_tag{$key};
        $buf .= qq{<$tag>$txt</$tag>\n}
      }
      else
      { $buf .= qq{<sdp_rule_item type='$key'>$txt</sdp_rule_item>\n}
      }
    }
    $buf .= qq{</Rule>\n};
  }
  else
  { $buf .= qq{ />\n};
  }

  return $buf;
}

# Format a section
sub format_failure_section
{ my ($ctl, $sum) = @_;

  return qq{<Failures summary='$sum'>\n};
}

sub format_result_section
{ return q{};
}

sub format_target_section
{ my ($ctl, $sum) = @_;

  return ($sum =~ m/^(.+) Target$/)
    ? qq{<Target id='$1'>\n}
    : q{};
}

sub format_type_section
{ my ($ctl, $sum) = @_;

  return ($sum =~ m/^(\w+) /)
    ? qq{<Target type='$1'>\n}
    : q{};
}

1;

__END__

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Driver::Convert|RDA::Driver::Convert>,
L<RDA::Request::CONVERT|RDA::Request::CONVERT>,
L<RDA::Text|RDA::Text>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2020, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
