# Convert.pm: Generic Conversions for OS.INST Reports

package Convert::OS::INST::Convert;

# $Id: Convert.pm,v 1.6 2014/08/19 16:13:58 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/Convert/OS/INST/Convert.pm,v 1.6 2014/08/19 16:13:58 RDA Exp $
#
# Change History
# 20140819  MSC  Improve the documentation.

=head1 NAME

Convert::OS::INST::Convert - Generic Conversions for OS.INST Reports

=head1 SYNOPSIS

 require Convert::OS::INST::Convert;

=head1 DESCRIPTION

This package regroups generic conversion methods for the OS.INST module reports.

It is only provided as plugin example and is thus incomplete by nature.

=cut

use strict;

BEGIN
{ use Exporter;
  use RDA::Text qw(get_string);
  use RDA::Driver::Convert;
}

# Define the global public variables
use vars qw($STRINGS $VERSION @ISA %PLUGIN);
$VERSION = sprintf('%d.%02d', q$Revision: 1.6 $ =~ /(\d+)\.(\d+)/);
@ISA     = qw(Exporter);
%PLUGIN  = (
  cnv => [{blk => {
             comps_xml => [
               [qr{\.xml\b}, \&RDA::Driver::Convert::merge_block]],
             inventory_xml => [
               [qr{\.xml\b}, \&RDA::Driver::Convert::merge_block]],
             },
           nam => 'Generic Conversions',
           rnk => 10,
           sel => \&RDA::Driver::Convert::sel_block,
           typ => 'B',
         },
        ],
  );

# Define the global private constants

# Define the global private variables

# Report the package version
sub Version
{ return $VERSION;
}

1;

__END__

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Driver::Convert|RDA::Driver::Convert>,
L<RDA::Request::CONVERT|RDA::Request::CONVERT>,
L<RDA::Text|RDA::Text>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2020, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
