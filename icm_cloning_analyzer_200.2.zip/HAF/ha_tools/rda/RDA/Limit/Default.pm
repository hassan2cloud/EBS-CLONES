# Default.pm: Class Used for Managing Limits for Default Mode

package RDA::Limit::Default;

# $Id: Default.pm,v 1.3 2015/11/06 10:35:43 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/RDA/Limit/Default.pm,v 1.3 2015/11/06 10:35:43 RDA Exp $
#
# Change History
# 20151105  MSC  Eliminate unused variable.

=head1 NAME

RDA::Limit::Default - Class Used for Managing Limits for Default Mode

=head1 SYNOPSIS

 require RDA::Limit::Default;

=head1 DESCRIPTION

The objects of the C<RDA::Limit::Default> class are used to manage limits for
collections based on age and volume.

The following methods are available:

=cut

use strict;

BEGIN
{ use Exporter;
  use RDA::Text qw(get_string);
  use RDA::Limit::Common;
  use RDA::Object;
  use RDA::Object::Buffer;
}

# Define the global public variables
use vars qw($STRINGS $VERSION @ISA);
$VERSION = sprintf('%d.%02d', q$Revision: 1.3 $ =~ /(\d+)\.(\d+)/);
@ISA     = qw(RDA::Limit::Common RDA::Object Exporter);

# Define the global private constants

# Define the global private variables

# Report the package version
sub Version
{ return $VERSION;
}

=head2 S<$h = RDA::Limit::Default-E<gt>new($collector)>

The limit control object constructor. This method enables you to specify the
collector object reference as an argument.

It is represented by a blessed hash reference. The following special keys are
used:

=over 12

=item S<    B<'oid' > > Object identifier

=item S<    B<'_col'> > Reference to the collector object

=item S<    B<'_def'> > Limit context definition hash

=item S<    B<'_key'> > Corresponding item key

=back

Internal keys are prefixed by an underscore.

=cut

sub new
{ my ($cls, $col) = @_;

  # Create the object and return its reference
  return bless {
    oid  => 'D',
    _col => $col,
    _def => {},
    _key => '.T_DFT',
    }, ref($cls) || $cls;
}

=head2 S<$h-E<gt>get_file_limit($context)>

This methods defines the file selection based on a recent last modification
time.

=cut

sub get_file_limit
{ my ($slf, $ctx) = @_;
  my ($val);

  # Apply an age limitation
  $val = eval {$slf->get_value($ctx, 'age')};
  return $slf->get_age_limit($val) if defined($val);

  # Apply the default treatment
  return $slf->select_item;
}

=head2 S<$h-E<gt>open_alert_log($file)>

This methods returns a buffer on the specified alert log file. It returns an
undefined value in case of errors.

=cut

sub open_alert_log
{ my ($slf, $fil) = @_;

  return RDA::Object::Buffer->new('R', $fil);
}

=head2 S<$h-E<gt>open_listener_log($file)>

This methods returns a tail buffer on the specified listener log file. It
returns an undefined value in case of errors.

=cut

sub open_listener_log
{ my ($slf, $fil, $siz) = @_;

  return RDA::Object::Buffer->new('T', $fil, $siz);
}

1;

__END__

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Limit::Common|RDA::Limit::Common>,
L<RDA::Object|RDA::Object>,
L<RDA::Object::Buffer|RDA::Object::Buffer>,
L<RDA::Object::Limit|RDA::Object::Limit>,
L<RDA::Text|RDA::Text>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2020, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
