# Net.pm: Net Routines

package RDA::Extern::Net;

# $Id: Net.pm,v 1.6 2015/08/18 20:47:20 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/RDA/Extern/Net.pm,v 1.6 2015/08/18 20:47:20 RDA Exp $
#
# Change History
# 20150818  MSC  Eliminate empty rows.

=head1 NAME

RDA::Extern::Net - Net Routines

=head1 SYNOPSIS

 require RDA::Extern::Net;

=head1 DESCRIPTION

The following method is available:

=cut

use strict;

BEGIN
{ use Exporter;
  use Socket qw(inet_ntoa AF_INET);
}

# Define the global public variables
use vars qw($VERSION @ISA);
$VERSION = sprintf('%d.%02d', q$Revision: 1.6 $ =~ /(\d+)\.(\d+)/);
@ISA     = qw(Exporter);

# Report the package version
sub Version
{ return $VERSION;
}

=head2 S<RDA::Extern::Net::reverse_lookup($ctx,$hst)>

This method gets the reverse lookup information.

=cut

sub reverse_lookup
{ my ($ctx, $hst) = @_;
  my ($alt, $nam, $rpt, @adr);

  if ($rpt = $ctx->get_report)
  { ($nam, $alt, undef, undef, @adr) = gethostbyname($hst);
    $rpt->write(q{|*Host Name*|}.$nam.qq{ |\n}) if defined($nam);
    if (ref($alt) eq 'ARRAY')
    { $rpt->write(q{|*Aliases*|}.join('%BR%', @{$alt}).qq{ |\n});
    }
    elsif (defined($alt))
    { $rpt->write(q{|*Aliases*|}.$alt.qq{ |\n});
    }
    foreach my $adr (@adr)
    { $rpt->write(q{|*Reverse Lookup of }.inet_ntoa($adr).q{*|}
        .gethostbyaddr($adr, AF_INET).qq{ |\n});
    }
  }
  return 1;
}

1;

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2020, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
