# Json.pm: Class Used for JSON Processing

package RDA::Library::Json;

# $Id: Json.pm,v 1.3 RDA Exp $
# ARCS: $Header: /RDA_8/src/scripting/lib/RDA/Library/Json.pm,v 1.2 RDA Exp $
#
# Change History
# 20180619  SJC  Correct $VERSION to reflect the file version.
# 20180301  SJC  Removed unrelated code that came from Http.pm.
# 20170718  DXM  Initial version.

=head1 NAME

RDA::Library::Json - Class Used for JSON Processing

=head1 SYNOPSIS

 require RDA::Library::Json;

=head1 DESCRIPTION

The objects of the C<RDA::Library::Json> class are used to process
JSON.

The following methods are available:

=cut

use strict;

BEGIN
{ use Exporter;
  use IO::File;
  use RDA::Text qw(get_string);
  use RDA::Value::List;
  use RDA::Value::Scalar qw(:value);
}

# Define the global public variables
use vars qw($STRINGS $VERSION @ISA);
$VERSION = sprintf('%d.%02d', q$Revision: 1.3 $ =~ /(\d+)\.(\d+)/);
@ISA     = qw(RDA::Driver::Library Exporter);

# Define the global private constants

# Define the global private variables
my %tb_fct = (
  'decodeJson'          => [\&_m_jsn_decode,       'X'],
  'encodeJson'          => [\&_m_jsn_encode,       'X'],
  'loadJson'            => [\&_m_jsn_load,         'X'],
  );

# Report the package version
sub Version
{ return $VERSION;
}

=head2 S<$h = RDA::Library::Json-E<gt>new($driver,$collector)>

The object constructor. It takes the library driver and collector references as
arguments.

C<RDA::Library::Json> is represented by a blessed hash reference. The following
special keys are used:

=over 12

=item S<    B<'_col'> > Reference to the collector object

=back

Internal keys are prefixed by an underscore.

=cut

sub new
{ my ($cls, $drv, $col) = @_;
  my ($slf);

  # Create the macro object
  $slf = bless {}, ref($cls) || $cls;

  # Check capabilities
  _can_json($slf);

  # Register the macros
  $drv->register($slf, [keys(%tb_fct)], qw(refresh suspend));

  # Return the object reference
  return refresh($slf, $col);
}

sub _can_json
{ my ($slf) = @_;

  eval 'require JSON';
  unless ($@)
  { $slf->{'_dec'} = \&_decode_xs;
    $slf->{'_enc'} = \&_encode_xs;
    return q{XS};
  }
  eval 'require JSON::PP';
  unless ($@)
  { $slf->{'_dec'} = \&_decode_pp;
    $slf->{'_enc'} = \&_encode_pp;
    return q{PP};
  }
  eval 'require JSON::Syck';
  unless ($@)
  { $slf->{'_dec'} = \&_decode_syck;
    $slf->{'_enc'} = \&_encode_syck;
    return q{Syck};
  }
  delete($tb_fct{'decodeJson'});
  delete($tb_fct{'encodeJson'});
  return q{};
}

=head2 S<$h-E<gt>call($name,...)>

This method executes the macro code.

=cut

sub call
{ my ($slf, $nam, @arg) = @_;

  return &{$tb_fct{$nam}->[0]}($slf, @arg);
}

=head2 S<$h-E<gt>delete_object>

This method deletes the library control object.

=cut

sub delete_object
{ RDA::Object::dump_caller($_[0], 'Library') if $RDA::Object::DELETE;
  undef %{$_[0]};
  undef $_[0];
  return;
}

=head2 S<$h-E<gt>refresh($col)>

This method updates the library control object for a new collector.

=cut

sub refresh
{ my ($slf, $col) = @_;

  $slf->{'_col'} = $col;
  return $slf;
}

=head2 S<$h-E<gt>run($name,$arg,$ctx)>

This method executes the macro with the specified argument list in a given
context.

=cut

sub run
{ my ($slf, $nam, $arg, $ctx) = @_;
  my ($fct, $ret, $typ);

  $fct = $tb_fct{$nam};
  $typ = $fct->[1];

  # Treat a native context
  return &{$fct->[0]}($slf, $ctx, $arg) if $typ eq 'X';

  # Treat an array context
  return RDA::Value::List::new_from_data(&{$fct->[0]}($slf, $ctx,
    $arg->eval_as_array)) if $typ eq 'L';

  # Treat a scalar context
  return defined($ret = &{$fct->[0]}($slf, $ctx, $arg->eval_as_array))
    ? RDA::Value::Scalar->new($typ, $ret)
    : $VAL_UNDEF;
}

=head1 JSON-RELATED MACROS

=head2 S<decodeJson($data)>

This macro returns data which is in JSON format into the appropriate type
(array / hash).

=cut

sub _m_jsn_decode
{ my ($slf, $ctx, $arg) = @_;

  return RDA::Value::Scalar::new_from_data(&{$slf->{'_dec'}}(
    $arg->eval_as_data));
}

sub _decode_pp
{ return JSON::PP::decode_json(@_);  ## no critic (Call)
}

sub _decode_syck
{ return JSON::Syck::Load(@_);
}

sub _decode_xs
{ return JSON::decode_json(@_);      ## no critic (Call)
}

=head2 S<encodeJson($data)>

This macro encodes data held in a string, array or hash into JSON format.

=cut

sub _m_jsn_encode
{ my ($slf, $ctx, $arg) = @_;

  return RDA::Value::Scalar::new_text(&{$slf->{'_enc'}}(
    $arg->eval_as_data))
}

sub _encode_pp
{ return JSON::PP::encode_json(@_);  ## no critic (Call)
}

sub _encode_syck
{ return JSON::Syck::Dump(@_);
}

sub _encode_xs
{ return JSON::encode_json(@_);      ## no critic (Call)
}

=head2 S<loadJson($path)>

This macro loads JSON data contained in the specified file into the
appropriate type (array / hash).

=cut

sub _m_jsn_load
{ my ($slf, $ctx, $arg) = @_;
  my ($buf, $ifh, $pth);

  $buf = q{};
  $ifh = IO::File->new;
  ($pth) = $arg->eval_as_data;
  $ifh->open($pth) or die get_string('ERR_OPEN', $pth, $!);
  local $/;  ## no critic (Local)
  $buf = <$ifh>;
  $ifh->close;
  return RDA::Value::Scalar::new_from_data(&{$slf->{'_dec'}}($buf));
}

1;

__END__

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Driver::Library|RDA::Driver::Library>,
L<RDA::Text|RDA::Text>,
L<RDA::Value::List|RDA::Value::List>,
L<RDA::Value::Scalar|RDA::Value::Scalar>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2020, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
