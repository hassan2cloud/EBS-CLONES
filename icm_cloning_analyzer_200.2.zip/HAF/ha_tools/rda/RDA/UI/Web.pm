# Web.pm: Web Access Command Package

package RDA::UI::Web;

# $Id: Web.pm,v 1.17 2015/06/24 07:07:25 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/RDA/UI/Web.pm,v 1.17 2015/06/24 07:07:25 RDA Exp $
#
# Change History
# 20150624  MSC  Allow to specify the path of the remote Perl command.

=head1 NAME

RDA::UI::Web - Web Access Command Package

=head1 SYNOPSIS

 <rda> <options> -XWeb <command> <switches> <arg> ...

 <sdci> <options> -XWeb <command> <switches> <arg> ...

=head1 DESCRIPTION

The following commands are available:

=cut

use strict;

BEGIN
{ use Exporter;
  use RDA::Text qw(get_string);
  use RDA::Agent;
  use RDA::Object::Access;
  use RDA::Object::Message;
  use RDA::Object::View;
  use RDA::Options;
}

# Define the global public variables
use vars qw($STRINGS $VERSION @ISA);
$VERSION = sprintf('%d.%02d', q$Revision: 1.17 $ =~ /(\d+)\.(\d+)/);
@ISA     = qw(Exporter);

# Define the global constants

# Define the global private variables

# Report the package version
sub Version
{ return $VERSION;
}

=head2 S<halt>

This command halts a running web server.

=cut

sub halt
{ my ($agt) = @_;

  return $agt->submit(q{.}, 'WEB.HALT');
}

=head2 S<help>

This command displays the command syntax and the related explanations.

=cut

sub help
{ return shift->submit(q{.}, 'DISPLAY.DSP_POD', package => __PACKAGE__);
}

=head2 S<list>

This command lists available web services.

=cut

sub list
{ my ($agt) = @_;
  my ($buf, $cfg, $dir, $dsc);

  # Generate the report
  $buf = q{};
  $cfg = $agt->get_config;
  $dir = $cfg->get_dir('D_RDA_INC', 'RDA/Web');
  if (opendir(SVC, $dir))
  { foreach my $pkg (sort readdir(SVC))
    { next unless $pkg =~ m/^(\w+)\.pm$/i;
      $buf .= lc($1).q{|}.$dsc.qq{\n}
        if defined($dsc = $cfg->get_title($dir, $pkg));
    }
    closedir(SVC);
  }

  # Display the service list
  return $agt->submit(q{.},
    RDA::Object::Message->new('DISPLAY.DSP_REPORT')->add_data($buf
    ? q{.M 2 '}.get_string('Services').qq{'\n}.$buf.qq{\n}
    : qq{.P\n}.get_string('NoServices').qq{\n\n}));
}

=head2 S<page url>

This command generates a help page and displays it.

=cut

sub page
{ my ($agt, $url) = @_;

  return $agt->submit(q{.}, 'WEB.PAGE', url => $url);
}

=head2 S<proxy [switches] [port] [password]>

This command starts a basic web server to review the reports in a remote report
directory structure. It uses basic authentication to restrict page access.

It supports the following command switches:

=over 14

=item B<  -H host>

Specifies the remote host (C<localhost> by default).

=item B<  -L login>

Specifies the remote login (current login by default).

=item B<  -P path>

Specifies the path of on the remote Perl command (detected by default).

=item B<  -R path>

Specifies the path of the RDA software directory on the remote host.

=item B<  -S path>

Specifies the path of the selected remote directory structure.

=item B<  -W path>

Specifies the path of the remote working directory.

=item B<  -h>

Enables halt mechanism (false by default).

=item B<  -p port>

Specifies the port number (C<8778> by default).

=item B<  -r>

Loads only the review-related Web services.

=item B<  -s svc,...>

Specifies the authorized web services (all by default).

=item B<  -u user>

Specifies the web user name (C<rda> by default).

=back

It asks for the password interactively unless a password is provided as an
argument.

You can access the start page for reviewing results with the following URL:

  http://<host>:<port>/package

This command forces to use an UTF-8 character set, which is required for the
web pages. Therefore some error or trace messages can contain invalid
characters when displayed at the console.

=cut

sub proxy  ## no critic (Complex)
{ my ($agt, @arg) = @_;
  my ($log, $opt, $pwd, %arg);

  my $col = $agt->get_collector;

  # Parse the options
  $opt = RDA::Options::getopts('H:L:P:R:S:TW:hnp:rs*tu:', \@arg);
  if (exists($opt->{'L'}))
  { ($log, $pwd) = split(/\//, $opt->{'L'}, 2);
    $log = length($log) ? RDA::Object::View->is_user($log) : undef
      if defined($log);
  }
  $arg{'host'}     = $opt->{'H'} if exists($opt->{'H'})
                                 && RDA::Object::View->is_host($opt->{'H'});
  $arg{'login'}    = defined($log)
                       ? $log
                       : $agt->get_config->get_login;
  $arg{'password'} = $pwd        if defined($pwd);
  $arg{'perl'}     = $opt->{'P'} if exists($opt->{'P'});
  $arg{'rda'}      = $opt->{'R'} if exists($opt->{'R'});
  $arg{'archive'}  = $opt->{'S'} if exists($opt->{'S'});
  $arg{'taint'}    = 0           if $opt->{'T'};
  $arg{'work'}     = $opt->{'W'} if exists($opt->{'W'});
  $arg{'pid'}      = 1           if $opt->{'h'};
  $arg{'port'}     = $opt->{'p'} if exists($opt->{'p'})
                                 && RDA::Object::View->is_port($opt->{'p'});
  $arg{'notice'}   = q{}         if $opt->{'n'};
  $arg{'private'}  = 1;
  $arg{'prefix'}   = q{/test}    if $opt->{'t'};
  $arg{'user'}     = exists($opt->{'u'}) ? $opt->{'u'} : 'rda';
  if (exists($opt->{'r'}))
  { $arg{'services'} = [qw(display explorer rda system tool)];
  }
  elsif (exists($opt->{'s'}))
  { $arg{'services'} = $opt->{'s'};
  }

  # Treat the arguments
  $pwd = q{};
  foreach my $arg (@arg)
  { if ($arg =~ m/\D/ || exists($arg{'port'}))
    { $pwd = $arg;
    }
    else
    { $arg{'port'} = $arg;
    }
  }
  return 0 unless $pwd || ($pwd = RDA::Object::Access::ask_password($agt,
    get_string('Password', $arg{'user'})));

  # Start the web server
  return $agt->submit(q{.}, 'WEB.PROXY', %arg, authentication => $pwd);
}

=head2 S<server [switches] [port] [password]>

This command starts a basic web server to review the reports in the report
directory structure. It uses basic authentication to restrict page access.

It supports the following command switches:

=over 14

=item B<  -h>

Enables halt mechanism (false by default).

=item B<  -p port>

Specifies the port number (C<8778> by default).

=item B<  -r>

Loads only the review-related Web services.

=item B<  -s svc,...>

Specifies the authorized web services (all by default).

=item B<  -u user>

Specifies the web user name (C<rda> by default).

=back

It asks for the password interactively unless a password is provided as an
argument.

You can access the start page for reviewing results with the following URL:

  http://<host>:<port>/package

This command forces to use an UTF-8 character set, which is required for the
web pages. Therefore some error or trace messages can contain invalid
characters when displayed at the console.

=cut

sub server
{ my ($agt, @arg) = @_;
  my ($opt, $pwd, %arg);

  # Parse the options
  $opt = RDA::Options::getopts('hnp:rs*tu:', \@arg);
  $arg{'pid'}     = 1           if $opt->{'h'};
  $arg{'port'}    = $opt->{'p'} if exists($opt->{'p'})
                                && RDA::Object::View->is_port($opt->{'p'});
  $arg{'notice'}  = q{}         if $opt->{'n'};
  $arg{'private'} = 1;
  $arg{'prefix'}  = q{/test}    if $opt->{'t'};
  $arg{'user'}    = exists($opt->{'u'}) ? $opt->{'u'} : 'rda';
  if (exists($opt->{'r'}))
  { $arg{'services'} = [qw(display explorer rda system tool)];
  }
  elsif (exists($opt->{'s'}))
  { $arg{'services'} = $opt->{'s'};
  }

  # Treat the arguments
  $pwd = q{};
  foreach my $arg (@arg)
  { if ($arg =~ m/\D/ || exists($arg{'port'}))
    { $pwd = $arg;
    }
    else
    { $arg{'port'} = $arg;
    }
  }
  return 0 unless $pwd || ($pwd = RDA::Object::Access::ask_password($agt,
    get_string('Password', $arg{'user'})));

  # Start the web server
  return $agt->submit(q{.}, 'WEB.SERVER', %arg, authentication => $pwd);
}

1;

__END__

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Object::Access|RDA::Object::Access>,
L<RDA::Object::Message|RDA::Object::Message>,
L<RDA::Object::View|RDA::Object::View>,
L<RDA::Options|RDA::Options>,
L<RDA::Request::DISPLAY|RDA::Request::DISPLAY>,
L<RDA::Request::WEB|RDA::Request::WEB>,
L<RDA::Text|RDA::Text>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2020, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
