# Vms.pm: VMS Methods for RDA::Object::Rda

package RDA::Local::Vms;

# $Id: Vms.pm,v 1.16 RDA Exp $
# ARCS: $Header: /home/cvs/cvs/RDA_8/src/scripting/lib/RDA/Local/Vms.pm,v 1.15 2015/06/11 08:00:04 RDA Exp $
#
# Change History
# 20181122  SJC  Change two parameter forms of CORE::open to three.
# 20150609  MSC  Add the can_spawn method.

=head1 NAME

RDA::Local::Vms - VMS Methods for RDA::Object::Rda

=head1 SYNOPSIS

 require RDA::Local::Vms;

=head1 DESCRIPTION

See L<RDA::Object::Rda|RDA::Object::Rda> and
L<RDA::Local::Unix|RDA::Local::Unix>. This package overrides the implementation
of these methods, not the semantics.

To assure more reproducible results with different Perl versions, some code is
derived from C<File::Spec>.

The following methods are available:

=cut

use strict;

BEGIN
{ use Exporter;
  use File::Spec;
  use RDA::Text qw(get_string);
  require File::Basename;
  eval 'use File::Spec::VMS';
}

# Define the global public variables
use vars qw($STRINGS $VERSION @ISA);
$VERSION = sprintf('%d.%02d', q$Revision: 1.16 $ =~ /(\d+)\.(\d+)/);

require RDA::Local::Unix;
@ISA = qw(RDA::Local::Unix Exporter);

# Define the global private constants

# Define the global private variables

# Report the package version
sub Version
{ return $VERSION;
}

=head2 S<RDA::Object::Rda-E<gt>as_bat([$path])>

This method adds a C<.com> extension to the specified path.

=cut

sub as_bat
{ my ($slf, $pth) = @_;

  return defined($pth) ? "$pth.com" : '.com';
}

=head2 S<RDA::Object::Rda-E<gt>as_cmd([$path])>

This method adds a C<.com> extension to the specified path.

=cut

sub as_cmd
{ my ($slf, $pth) = @_;

  return defined($pth) ? "$pth.com" : '.com';
}

=head2 S<RDA::Object::Rda-E<gt>as_exe([$path])>

This method adds a C<.exe> extension to the specified path.

=cut

sub as_exe
{ my ($slf, $pth) = @_;

  return defined($pth) ? "$pth.exe" : '.exe';
}

=head2 S<RDA::Object::Rda-E<gt>basename($file[,@suf])>

This method extracts the base name of the file specification and  removes the
suffix when it belongs to the suffix list. It matches each element of this list
as a string against the end of the name.

=cut

sub basename
{ my ($slf, $fil, @suf) = @_;

  return defined($fil) ? File::Basename::basename($fil, @suf) : undef;
}

=head2 S<RDA::Object::Rda-E<gt>can_spawn>

This method indicates whether it is possible to launch background processes.

=cut

sub can_spawn
{ return 0;
}

=head2 S<RDA::Object::Rda-E<gt>cat_dir([$dir...,]$dir)>

This method concatenates directory names to form a complete path ending with a
directory. It removes the trailing slash from the resulting string, except for
the root directory.

=cut

sub cat_dir
{ my $slf = shift;

  return File::Spec->catdir(@_);
}

=head2 S<RDA::Object::Rda-E<gt>cat_file([$dir...,]$file)>

This method concatenates directory names and a file name to form a complete path
ending with a file name.

=cut

sub cat_file
{ my $slf = shift;

  return File::Spec->catfile(@_);
}

=head2 S<RDA::Object::Rda-E<gt>clean_path($path)>

This method performs a logical cleanup of a path.

=cut

sub clean_path
{ my ($slf, $pth) = @_;

  return (!defined($pth))       ? undef :
         (ref($pth) eq 'ARRAY') ? File::Spec->catfile(@{$pth}) :
                                  $pth;
}

*clean_native = \&clean_path;

=head2 S<RDA::Object::Rda-E<gt>current_dir>

This method returns a string representation of the current directory (C<[]> for
VMS).

=cut

sub current_dir
{ return q{[]};
}

=head2 S<RDA::Object::Rda-E<gt>dev_null>

This method returns a string representation of the null device.

=cut

sub dev_null
{ return q{NLA0:};
}

=head2 S<RDA::Object::Rda-E<gt>dev_tty>

This method returns a string representation of the terminal device.

=cut

sub dev_tty
{ return q{SYS$OUTPUT};  ## no critic (Interpolation)
}

=head2 S<RDA::Object::Rda-E<gt>dirname($file)>

This method returns the directory portion of the input file specification.

=cut

sub dirname
{ my ($slf, $fil) = @_;

  return defined($fil) ? File::Basename::dirname($fil) : undef;
}

=head2 S<RDA::Object::Rda-E<gt>find_path($cmd[,$flg])>

This method explores the path to find where a command is located. When the
command is found, it returns a full path name. Otherwise, it returns an
undefined variable. It only considers files or symbolic links in its
search. Unless the flag is set, the file path is quoted as required by a
command shell.

=cut

sub find_path
{ my ($slf, $pth, $cmd) = @_;
  my ($lin);

  if ($cmd)
  { eval {
      local $SIG{'__WARN__'} = sub { };
      local $SIG{'PIPE'} = 'IGNORE';
      open(PIPE, qq{-|}, qq{$cmd "-h"})  ## no critic (Handle)
        or die "Bad open\n";
      $lin = <PIPE>;
      while (<PIPE>)
      { ; # Need a loop to prevent pipe errors
      }
      close(PIPE) or die "Bad close\n";;
    };
    return $cmd if defined($lin) && $lin !~ m/^\%DCL\-/;
  }
  return;
}

=head2 S<RDA::Object::Rda-E<gt>get_last_modify($file[,$default])>

This method gets the last modification date of the file. In returns the default
value when there are problems.

=cut

sub get_last_modify
{ my ($slf, $fil, $dft) = @_;
  my @sta = stat($fil);
  return defined($sta[9]) ? $sta[9] : $dft;
}

=head2 S<RDA::Object::Rda-E<gt>get_path>

This method returns the environment variable PATH as a list.

=cut

sub get_path
{ return File::Spec->path();
}

=head2 S<RDA::Object::Rda-E<gt>is_absolute($path)>

This method indicates whether the argument is an absolute path.

=cut

sub is_absolute
{ my ($slf, $pth) = @_;

  return defined($pth)
    ? File::Spec->file_name_is_absolute($pth)
    : 0;
}

=head2 S<$h-E<gt>is_path($string)>

This method verifies that the string does not contain characters invalid in a
path.

=cut

sub is_path
{ my ($slf, $pth) = @_;

  return unless defined($pth);
  return $1 if $pth =~ m/^([\-\w\:\;\$\.\[\]]+)$/;
  die get_string('BAD_PATH', $pth);
}

=head2 S<RDA::Object::Rda-E<gt>is_unix>

This method returns a true value when the operating system belongs to the UNIX
family.

=cut

sub is_unix
{ return 0;
}

=head2 S<RDA::Object::Rda-E<gt>is_vms>

This method returns a true value when the operating system is VMS.

=cut

sub is_vms
{ return 1;
}

=head2 S<RDA::Object::Rda-E<gt>parse_path($path[,@suf])>

This method divides a file path into the directories, its file name, and
optionally the file suffix. The directory part contains everything up to and
including the last directory separator in the $path including the volume, when
applicable. The remainder of the path is the file name.

=cut

sub parse_path
{ my ($slf, $pth, @suf) = @_;
  my ($dir, $ext, $fil, @ext);

  return () unless defined($pth);
  ($fil, $dir, $ext) = File::Basename::fileparse($pth, @suf);
  @ext = ($ext) if defined($ext) && $ext ne q{};
  return ($slf->cat_dir($dir), $fil, @ext);
}

=head2 S<RDA::Object::Rda-E<gt>quote($string)>

This method encodes a string to be considered as a single argument by a command
shell. No variable substitution is attempted for VMS.

=cut

sub quote
{ my ($slf, $str) = @_;

  return $str unless defined($str) && $str =~ m/[\s\@\"\,]/;
  $str =~ s{"}{""}g;
  return q{"}.$str.q{"};
}

=head2 S<RDA::Object::Rda-E<gt>quote2($string)>

This method is similar to the C<quote> method but the result does not contain
the leading and trailing quotation marks.

=cut

sub quote2
{ my ($slf, $str) = @_;

  return $str unless defined($str) && $str =~ m/[\s\@\"\,]/;
  $str =~ s{"}{""}g;
  return $str;
}

=head2 S<RDA::Object::Rda-E<gt>split_dir($path)>

This method returns the list of directories contained in the specified
path. The first element will includes the volume information. It returns an
empty list when the path is missing.

=cut

sub split_dir
{ my ($slf, $pth) = @_;
  my ($vol, $dir, $fil, @dir);

  ## no critic (Explicit)
  if (defined($pth))
  { ($vol, $dir, $fil) = File::Spec::VMS->splitpath($pth);
    @dir = File::Spec::VMS->splitdir($dir);
    $dir[0] = ($vol eq q{} && $dir[0] eq q{})
      ? q{[]}
      : File::Spec::VMS->catpath($vol, $dir[0], q{});
  }
  return @dir;
}

=head2 S<RDA::Object::Rda-E<gt>split_volume($path)>

This method separates the volume from the other path information. It returns an
empty list when the path is missing.

=cut

sub split_volume
{ my ($slf, $pth) = @_;
  my ($dir, $fil, $vol);

  ## no critic (Explicit)
  return () unless defined($pth);
  return (q{}, []) if $pth eq q{};
  ($vol, $dir, $fil) = File::Spec::VMS->splitpath($pth);
  return ($vol, File::Spec::VMS->catpath(q{}, $dir, $fil));
}

=head2 S<RDA::Object::Rda-E<gt>unquote($string)>

This method removes the quoting characters from a string.

=cut

sub unquote
{ my ($slf, $str) = @_;
  my ($buf);

  if (defined($str))
  { for ($buf = q{} ;;)  ## no critic (For)
    { return $buf.$str unless $str =~ s/\A([^\"]*)\"//s;
      $buf .= $1;
      $buf .= $1 while $str =~ s/\A([^\"]*\")\"//s;
      return $buf.$str unless $str =~ s/\A([^\"]*)\"//s;
      $buf .= $1;
    }
  }
  return;
}

=head2 S<RDA::Object::Rda-E<gt>up_dir>

This method returns a string representation of the parent directory (C<..> for
VMS).

=cut

sub up_dir
{ return q{[-]};
}

# --- Auxiliary routines ------------------------------------------------------

# Get uname information
sub sys_uname
{ my ($slf) = @_;
  my ($sys);

  # Try to get it from perl
  eval {
    require POSIX;
    $sys = [POSIX::uname()];  ## no critic (Call)
  };
  return $sys unless $@;

  # Otherwise, give up
  return [q{?}, q{?}, q{?}, q{?}, q{?}];
}

1;

__END__

=head1 SEE ALSO

L<RDA::Agent|RDA::Agent>,
L<RDA::Local::Unix|RDA::Local::Unix>,
L<RDA::Object::Rda|RDA::Object::Rda>,
L<RDA::Text|RDA::Text>

=head1 COPYRIGHT NOTICE

Copyright (c) 2002, 2020, Oracle and/or its affiliates. All rights reserved.

=head1 TRADEMARK NOTICE

Oracle and Java are registered trademarks of Oracle and/or its
affiliates. Other names may be trademarks of their respective owners.

=cut
